﻿using System.Windows;
using System.Windows.Controls;

// Name: Mohammed Karim El Moussadeq
// Date: 2024-10-01
// Description: A simple Tic Tac Toe game created in WPF with That shows scores, handle player turns, shows winner or if it's a draw, has a reset and exit button.
namespace TicTacToe
{
    public partial class MainWindow : Window
    {
        // declare variables 
        private char currentPlayer = 'X';
        private int scoreX = 0;
        private int scoreO = 0;
        private int cats = 0;

        public MainWindow()
        {
            InitializeComponent();
            RestartBoard();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // Handle button click for game moves
            if (sender is Button Button && string.IsNullOrEmpty(Button.Content?.ToString()))
            {
                Button.Content = currentPlayer.ToString();
                Button.IsEnabled = false;

                if (CheckWinner())
                {
                    // Update score and show message
                    if (currentPlayer == 'X')
                    {
                        scoreX++;
                        TextBoxScoreX.Text = scoreX.ToString();
                        MessageBox.Show("X won the game!");
                    }
                    else
                    {
                        scoreO++;
                        TextBoxScoreO.Text = scoreO.ToString();
                        MessageBox.Show("O won the game!");
                    }
                    RestartBoard();
                    return;
                }
                // Check for draw
                if (IsBoardFull())
                {
                    cats++;
                    CatsResult.Text = cats.ToString();
                    MessageBox.Show("It's a draw!");
                    RestartBoard();
                    return;
                }
                // Switch player turns
                currentPlayer = currentPlayer == 'X' ? 'O' : 'X';
                // to show the current player if it's player X or O
                CurrentPlayer.Text = currentPlayer.ToString();
            }
        }
        // Check all winning combinations
        private bool CheckWinner()
        {
            // Row wins
            if (IsMatch(ButtonTopLeft, ButtonTopMid, ButtonTopRight)) return true;
            if (IsMatch(ButtonMiddleLeft, ButtonMiddleMiddle, ButtonMiddleRight)) return true;
            if (IsMatch(ButtonBottomLeft, ButtonBottomMiddle, ButtonBottomRight)) return true;

            // Column wins
            if (IsMatch(ButtonTopLeft, ButtonMiddleLeft, ButtonBottomLeft)) return true;
            if (IsMatch(ButtonTopMid, ButtonMiddleMiddle, ButtonBottomMiddle)) return true;
            if (IsMatch(ButtonTopRight, ButtonMiddleRight, ButtonBottomRight)) return true;

            // Diagonal wins
            if (IsMatch(ButtonTopLeft, ButtonMiddleMiddle, ButtonBottomRight)) return true;
            if (IsMatch(ButtonTopRight, ButtonMiddleMiddle, ButtonBottomLeft)) return true;

            return false;
        }
        // Check if three buttons match
        private bool IsMatch(Button button1, Button button2, Button button3)
        {
            // Get button contents
            string? c1 = button1.Content?.ToString();
            string? c2 = button2.Content?.ToString();
            string? c3 = button3.Content?.ToString();

            return !string.IsNullOrEmpty(c1) && c1 == c2 && c2 == c3;
        }
        // Check if the board is full
        private bool IsBoardFull()
        {
            return !string.IsNullOrEmpty(ButtonTopLeft.Content?.ToString()) &&
                   !string.IsNullOrEmpty(ButtonTopMid.Content?.ToString()) &&
                   !string.IsNullOrEmpty(ButtonTopRight.Content?.ToString()) &&
                   !string.IsNullOrEmpty(ButtonMiddleLeft.Content?.ToString()) &&
                   !string.IsNullOrEmpty(ButtonMiddleMiddle.Content?.ToString()) &&
                   !string.IsNullOrEmpty(ButtonMiddleRight.Content?.ToString()) &&
                   !string.IsNullOrEmpty(ButtonBottomLeft.Content?.ToString()) &&
                   !string.IsNullOrEmpty(ButtonBottomMiddle.Content?.ToString()) &&
                   !string.IsNullOrEmpty(ButtonBottomRight.Content?.ToString());
        }

        private void RestartBoard()
        {   // Clear all buttons and reset for new game
            foreach (var button in new[]
            {
                ButtonTopLeft, ButtonTopMid, ButtonTopRight,
                ButtonMiddleLeft, ButtonMiddleMiddle, ButtonMiddleRight,
                ButtonBottomLeft, ButtonBottomMiddle, ButtonBottomRight
            })
            {   // Clear button content and enable it
                button.Content = "";
                button.IsEnabled = true;
                button.Background = SystemColors.ControlLightBrush;
            }
            
            currentPlayer = 'X';
        }

        private void ButtonRestart_Click(object sender, RoutedEventArgs e)
        {
            // Reset scores and board
            scoreX = scoreO = cats = 0;
            TextBoxScoreX.Text = "";
            TextBoxScoreO.Text = "";
            CatsResult.Text = "";
            RestartBoard();
        }

        private void ButtonExit_Click(object sender, RoutedEventArgs e)
        {
            // Close the application
            Application.Current.Shutdown();
        }
    }
}